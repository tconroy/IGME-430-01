﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace ConsoleMessageServer
{
    class Server
    {
        public enum MessageType
        {
            Joined,
            Left,
            Message
        }

        Socket udpSocket;
        List<EndPoint> udpClients = new List<EndPoint>();
        byte[] recBuffer = new byte[512];

        public void startup()
        {

        }

    }
}
